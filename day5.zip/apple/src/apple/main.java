package apple;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		game g1=new game();
		g1.initgame();
		g1.play();
	}

}
