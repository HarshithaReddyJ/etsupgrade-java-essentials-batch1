package apple;
import java.util.*;
public class Player 
{
	Scanner obj=new Scanner(System.in);
	String name;
	int score=0;
	public void getdetails()
	{
		System.out.println("enter player name");
		name=obj.next();
	}
	
}
