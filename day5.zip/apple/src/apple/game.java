package apple;

public class game 
{
	question[] questions=new question[2];
	Player player= new Player();
	
	String[] questionsdata= {"India is a federal union comprising twenty-nine states and how many union territories?","Which of the following is the capital of Arunachal Pradesh?"
			};
	String[] option1= {"six","Itanagar"};
	String[] option2= {"seven","Dispur"};
	String[] option3= {"eight","Imphal"};
	String[] option4= {"nine","Panaji"};
	int[] answers= {2,1};
	
	public void initgame() {
		for(int i=0;i<2;i++) {
			questions[i]=new question();
		}
		/*questions[0].question=" India is a federal union comprising twenty-nine states and how many union territories?";
		questions[0].option1="six";
		questions[0].option1="seven";
		questions[0].option1="eight";
		questions[0].option1="nine";
		questions[0].correctAnswer=2;
		
		questions[1].question="Which of the following is the capital of Arunachal Pradesh?";
		questions[1].option1="Itanagar";
		questions[1].option1="Dispur";
		questions[1].option1="Imphal";
		questions[1].option1=" Panaji";
		questions[1].correctAnswer=1;*/
		for(int i=0;i<2;i++)
		{
			questions[i].question=questionsdata[i];
			questions[i].option1=option1[i];
			questions[i].option2=option2[i];
			questions[i].option3=option3[i];
			questions[i].option4=option4[i];
			questions[i].correctAnswer=answers[i];
		}
		
		
	}
	public void play()
	{
		player.getdetails();
		
			for(int i=0;i<2;i++)
			{
				boolean status=questions[i].askquestion();
				if(status==true)
				{
					System.out.println("omg i scored the  mark");
					player.score+=1;
				}
				else
				{
					System.out.println("lost mark");
				}
			}
		System.out.println(player.name+" your score is " +player.score);
           		
	}
}